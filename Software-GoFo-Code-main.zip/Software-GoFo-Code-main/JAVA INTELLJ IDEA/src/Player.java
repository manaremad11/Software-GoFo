import java.util.ArrayList;

public class Player extends User {

    //Creating new player.
    Player(String un, String em, String pass, int id) {
        super(un, em, pass, id);
    }
}